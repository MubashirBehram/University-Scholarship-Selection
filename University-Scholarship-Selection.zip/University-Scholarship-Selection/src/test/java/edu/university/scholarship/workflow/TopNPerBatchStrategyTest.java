package edu.university.scholarship.workflow;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.Test;

class TopNPerBatchStrategyTest {
    private final TopNPerBatchStrategy strategy = new TopNPerBatchStrategy();

    @Test
    void ranksByGpaAndMarksConfiguredTopCandidates() {
        List<RankedStudent> ranked = strategy.rank(List.of(
                student("S2", "3.70"),
                student("S1", "3.95"),
                student("S3", "3.20")), 1, new BigDecimal("3.00"));

        assertEquals(List.of("S1", "S2", "S3"), ranked.stream().map(RankedStudent::studentId).toList());
        assertTrue(ranked.get(0).proposed());
        assertFalse(ranked.get(1).proposed());
    }

    @Test
    void proposesAllStudentsTiedAtTheCutoffForStaffReview() {
        List<RankedStudent> ranked = strategy.rank(List.of(
                student("S1", "3.90"),
                student("S2", "3.90"),
                student("S3", "3.50")), 1, new BigDecimal("3.00"));

        assertTrue(ranked.get(0).proposed());
        assertTrue(ranked.get(1).proposed());
        assertTrue(ranked.get(0).tieAtCutoff());
        assertTrue(ranked.get(1).tieAtCutoff());
        assertFalse(ranked.get(2).proposed());
    }

    @Test
    void excludesStudentsBelowMinimumGpa() {
        List<RankedStudent> ranked = strategy.rank(List.of(
                student("S1", "3.00"),
                student("S2", "2.99")), 1, new BigDecimal("3.00"));

        assertEquals(1, ranked.size());
        assertEquals("S1", ranked.get(0).studentId());
    }

    private RankedStudent student(String id, String gpa) {
        return new RankedStudent(id, 1, "Batch A", id, id + "@example.edu",
                new BigDecimal(gpa), 0, false, false);
    }
}
