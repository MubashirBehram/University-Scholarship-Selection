USE university_scholarship;

INSERT INTO batches (batch_name, program_name) VALUES
  ('BSSE-2023', 'BS Software Engineering'),
  ('BSCS-2023', 'BS Computer Science');

INSERT INTO result_periods (period_code) VALUES ('2026-SPRING');

INSERT INTO students (student_id, batch_id, full_name, email) VALUES
  ('DEMO-001', (SELECT batch_id FROM batches WHERE batch_name = 'BSSE-2023'), 'Ayesha Demo', 'ayesha@example.edu'),
  ('DEMO-002', (SELECT batch_id FROM batches WHERE batch_name = 'BSSE-2023'), 'Hamza Demo', 'hamza@example.edu'),
  ('DEMO-003', (SELECT batch_id FROM batches WHERE batch_name = 'BSCS-2023'), 'Sara Demo', 'sara@example.edu'),
  ('DEMO-004', (SELECT batch_id FROM batches WHERE batch_name = 'BSCS-2023'), 'Ali Demo', 'ali@example.edu');

INSERT INTO student_results (student_id, period_code, gpa) VALUES
  ('DEMO-001', '2026-SPRING', 3.95),
  ('DEMO-002', '2026-SPRING', 3.72),
  ('DEMO-003', '2026-SPRING', 3.88),
  ('DEMO-004', '2026-SPRING', 3.88);

INSERT INTO scholarship_rules (batch_id, period_code, slots_per_batch, minimum_gpa) VALUES
  ((SELECT batch_id FROM batches WHERE batch_name = 'BSSE-2023'), '2026-SPRING', 1, 3.00),
  ((SELECT batch_id FROM batches WHERE batch_name = 'BSCS-2023'), '2026-SPRING', 1, 3.00);
