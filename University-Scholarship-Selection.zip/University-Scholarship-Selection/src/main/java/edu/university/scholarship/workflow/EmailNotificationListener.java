package edu.university.scholarship.workflow;

import edu.university.scholarship.config.Db;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

public final class EmailNotificationListener implements ScholarshipEventListener {
    @Override
    public void onEvent(ScholarshipEvent event) throws Exception {
        if (alreadySent(event)) {
            return;
        }
        try {
            send(event);
            record(event, "SENT", null);
        } catch (Exception ex) {
            record(event, "FAILED", safeMessage(ex));
            throw new Exception("Email to " + event.recipientEmail() + " failed; the failure was logged.", ex);
        }
    }

    private boolean alreadySent(ScholarshipEvent event) throws Exception {
        String sql = "SELECT status FROM email_logs WHERE candidate_id = ? AND email_type = ?";
        try (Connection connection = Db.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setLong(1, event.candidateId());
            statement.setString(2, event.type().name());
            try (ResultSet result = statement.executeQuery()) {
                return result.next() && "SENT".equals(result.getString("status"));
            }
        }
    }

    private void send(ScholarshipEvent event) throws MessagingException {
        String host = required("SMTP_HOST");
        String port = required("SMTP_PORT");
        String from = required("SMTP_FROM");
        String username = System.getenv("SMTP_USER");
        String password = System.getenv("SMTP_PASSWORD");
        Properties properties = new Properties();
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);
        properties.put("mail.smtp.auth", Boolean.toString(username != null && !username.isBlank()));
        properties.put("mail.smtp.starttls.enable", Boolean.toString(
                "true".equalsIgnoreCase(System.getenv("SMTP_STARTTLS"))));
        Session session;
        if (username != null && !username.isBlank() && password != null) {
            session = Session.getInstance(properties, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, password);
                }
            });
        } else {
            session = Session.getInstance(properties);
        }

        String subject;
        String body;
        if (event.type() == ScholarshipEvent.Type.AWARD) {
            subject = "Scholarship award confirmation";
            body = "Dear " + event.studentName() + ",\n\n"
                    + "The university has confirmed your scholarship for result period "
                    + event.periodCode() + ". Please contact the scholarship office if you have questions.\n\n"
                    + "University Scholarship Office";
        } else {
            subject = "Scholarship check ready for collection";
            body = "Dear " + event.studentName() + ",\n\n"
                    + "Your scholarship payment check is ready for collection. Please contact the scholarship office "
                    + "to confirm collection details.\n\nUniversity Scholarship Office";
        }

        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(from));
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(event.recipientEmail()));
        message.setSubject(subject, "UTF-8");
        message.setText(body, "UTF-8");
        Transport.send(message);
    }

    private void record(ScholarshipEvent event, String status, String error) throws Exception {
        String sql = """
                INSERT INTO email_logs (candidate_id, email_type, recipient_email, status, error_message)
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE recipient_email = VALUES(recipient_email),
                    status = VALUES(status), error_message = VALUES(error_message), sent_at = CURRENT_TIMESTAMP
                """;
        try (Connection connection = Db.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setLong(1, event.candidateId());
            statement.setString(2, event.type().name());
            statement.setString(3, event.recipientEmail());
            statement.setString(4, status);
            statement.setString(5, error);
            statement.executeUpdate();
        }
    }

    private String required(String name) {
        String value = System.getenv(name);
        if (value == null || value.isBlank()) {
            throw new IllegalStateException(name + " must be configured to send email.");
        }
        return value;
    }

    private String safeMessage(Exception ex) {
        String message = ex.getMessage();
        return message == null ? ex.getClass().getSimpleName() : message.substring(0, Math.min(message.length(), 500));
    }
}
