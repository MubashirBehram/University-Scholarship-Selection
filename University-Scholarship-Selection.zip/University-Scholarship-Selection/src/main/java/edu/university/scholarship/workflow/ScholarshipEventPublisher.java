package edu.university.scholarship.workflow;

import java.util.List;

public final class ScholarshipEventPublisher {
    private final List<ScholarshipEventListener> listeners;

    public ScholarshipEventPublisher(List<ScholarshipEventListener> listeners) {
        this.listeners = List.copyOf(listeners);
    }

    public void publish(ScholarshipEvent event) throws Exception {
        Exception failure = null;
        for (ScholarshipEventListener listener : listeners) {
            try {
                listener.onEvent(event);
            } catch (Exception ex) {
                if (failure == null) {
                    failure = new Exception("One or more notification listeners failed.");
                }
                failure.addSuppressed(ex);
            }
        }
        if (failure != null) {
            throw failure;
        }
    }
}
