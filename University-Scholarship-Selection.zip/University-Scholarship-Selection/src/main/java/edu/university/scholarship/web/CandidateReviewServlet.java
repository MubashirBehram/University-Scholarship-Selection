package edu.university.scholarship.web;

import edu.university.scholarship.workflow.ScholarshipWorkflowFacade;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CandidateReviewServlet extends HttpServlet {
    private final ScholarshipWorkflowFacade workflow = new ScholarshipWorkflowFacade();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        long runId;
        try {
            runId = Long.parseLong(Web.parameter(request, "runId"));
            if (runId < 1) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "A valid selection run is required.");
            return;
        }
        try {
            request.setAttribute("runId", runId);
            request.setAttribute("runStatus", workflow.getRunStatus(runId));
            request.setAttribute("candidates", workflow.getCandidates(runId));
            request.setAttribute("exceptions", workflow.getExceptions(runId));
            request.setAttribute("csrfToken", Web.csrfToken(request.getSession()));
            Web.consumeFlash(request);
            request.getRequestDispatcher("/WEB-INF/views/staff/candidates.jsp").forward(request, response);
        } catch (Exception ex) {
            throw new ServletException("Unable to load the candidate review. Check the database and try again.", ex);
        }
    }
}
