package edu.university.scholarship.workflow;

public record ScholarshipEvent(
        long candidateId,
        String studentId,
        String studentName,
        String recipientEmail,
        String periodCode,
        String batchName,
        Type type) {
    public enum Type {
        AWARD,
        CHECK_COLLECTION
    }
}
