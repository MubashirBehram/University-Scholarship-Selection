package edu.university.scholarship.web;

import edu.university.scholarship.config.Db;
import edu.university.scholarship.security.PasswordUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet(urlPatterns = {"/login", "/logout"})
public class AuthServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (request.getServletPath().equals("/logout")) {
            response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            return;
        }
        request.setAttribute("csrfToken", Web.csrfToken(request.getSession()));
        Web.consumeFlash(request);
        request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (!Web.validCsrf(request)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Your form expired. Please try again.");
            return;
        }
        if (request.getServletPath().equals("/logout")) {
            if (request.getSession(false) != null) {
                request.getSession(false).invalidate();
            }
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }
        String email = Web.parameter(request, "email").toLowerCase();
        String password = request.getParameter("password");
        if (!Web.validEmail(email) || password == null || password.length() > 128) {
            Web.flash(request, "error", "Enter a valid email and password.");
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        String sql = "SELECT staff_id, full_name, password_hash FROM staff_users WHERE email = ?";
        try (Connection connection = Db.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, email);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next() || !PasswordUtil.verify(password.toCharArray(), result.getString("password_hash"))) {
                    Web.flash(request, "error", "The email or password was not recognized.");
                    response.sendRedirect(request.getContextPath() + "/login");
                    return;
                }
                request.changeSessionId();
                request.getSession().setAttribute("staffId", result.getLong("staff_id"));
                request.getSession().setAttribute("staffName", result.getString("full_name"));
                request.getSession().removeAttribute("csrfToken");
            }
            response.sendRedirect(request.getContextPath() + "/staff/dashboard");
        } catch (Exception ex) {
            throw new ServletException("Unable to sign in. Check the database configuration and try again.", ex);
        } finally {
            if (password != null) {
                java.util.Arrays.fill(password.toCharArray(), '\0');
            }
        }
    }
}
