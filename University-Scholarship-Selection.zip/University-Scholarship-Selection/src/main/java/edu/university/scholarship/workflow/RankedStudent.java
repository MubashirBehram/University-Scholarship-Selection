package edu.university.scholarship.workflow;

import java.math.BigDecimal;

public record RankedStudent(
        String studentId,
        long batchId,
        String batchName,
        String fullName,
        String email,
        BigDecimal gpa,
        int rank,
        boolean tieAtCutoff,
        boolean proposed) {
}
