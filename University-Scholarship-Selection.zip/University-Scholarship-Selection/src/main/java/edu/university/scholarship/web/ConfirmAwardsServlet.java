package edu.university.scholarship.web;

import edu.university.scholarship.workflow.ScholarshipWorkflowFacade;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ConfirmAwardsServlet extends HttpServlet {
    private final ScholarshipWorkflowFacade workflow = new ScholarshipWorkflowFacade();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (!Web.validCsrf(request)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Your form expired. Please try again.");
            return;
        }
        long runId;
        List<Long> selected = new ArrayList<>();
        try {
            runId = Long.parseLong(Web.parameter(request, "runId"));
            for (String value : request.getParameterValues("candidateIds") == null
                    ? new String[0] : request.getParameterValues("candidateIds")) {
                selected.add(Long.parseLong(value));
            }
        } catch (NumberFormatException ex) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "The selection form contains an invalid identifier.");
            return;
        }
        try {
            workflow.confirmAwards(runId, Web.staffId(request), selected);
            Web.flash(request, "success", "Awards were confirmed. Check email logs for delivery outcomes.");
        } catch (Exception ex) {
            Web.flash(request, "error", ex.getMessage());
        }
        response.sendRedirect(request.getContextPath() + "/staff/candidates?runId=" + runId);
    }
}
