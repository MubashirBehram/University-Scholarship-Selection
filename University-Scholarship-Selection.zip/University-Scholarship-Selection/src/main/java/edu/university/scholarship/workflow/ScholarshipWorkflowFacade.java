package edu.university.scholarship.workflow;

import edu.university.scholarship.config.Db;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ScholarshipWorkflowFacade {
    private final ScholarshipSelectionStrategy strategy;
    private final ScholarshipEventPublisher events;

    public ScholarshipWorkflowFacade() {
        this(new TopNPerBatchStrategy(),
                new ScholarshipEventPublisher(List.of(new EmailNotificationListener())));
    }

    ScholarshipWorkflowFacade(ScholarshipSelectionStrategy strategy, ScholarshipEventPublisher events) {
        this.strategy = strategy;
        this.events = events;
    }

    public long releaseResultsAndPrepareCandidates(String period, long staffId) throws Exception {
        try (Connection connection = Db.getConnection()) {
            connection.setAutoCommit(false);
            try {
                try (PreparedStatement lock = connection.prepareStatement(
                        "SELECT status FROM result_periods WHERE period_code = ? FOR UPDATE")) {
                    lock.setString(1, period);
                    try (ResultSet result = lock.executeQuery()) {
                        if (!result.next()) {
                            throw new SQLException("No imported result period was found.");
                        }
                        if (!"IMPORTED".equals(result.getString("status"))) {
                            throw new SQLException("This result period has already been released.");
                        }
                    }
                }

                List<BatchResults> batches = loadBatchResults(connection, period);
                if (batches.isEmpty()) {
                    throw new SQLException("The result period contains no student results.");
                }

                long runId = insertRun(connection, period, staffId);
                int rankedCount = 0;
                for (BatchResults batch : batches) {
                    if (batch.slots() == null) {
                        insertException(connection, runId, batch.batchId(), null,
                                "No scholarship rule is configured for batch " + batch.batchName() + ".");
                        continue;
                    }
                    if (batch.students().isEmpty()) {
                        continue;
                    }
                    List<RankedStudent> ranked = strategy.rank(batch.students(), batch.slots(), batch.minimumGpa());
                    saveCandidates(connection, runId, ranked);
                    rankedCount += ranked.size();
                    if (ranked.isEmpty()) {
                        insertException(connection, runId, batch.batchId(), null,
                                "No students meet the minimum GPA for batch " + batch.batchName() + ".");
                    }
                }
                if (rankedCount == 0) {
                    throw new SQLException("No eligible candidates were found. Check batch rules and imported results.");
                }

                try (PreparedStatement update = connection.prepareStatement(
                        "UPDATE result_periods SET status='RELEASED', released_at=CURRENT_TIMESTAMP, released_by=? "
                                + "WHERE period_code=? AND status='IMPORTED'")) {
                    update.setLong(1, staffId);
                    update.setString(2, period);
                    if (update.executeUpdate() != 1) {
                        throw new SQLException("The result period status changed. Refresh and try again.");
                    }
                }
                connection.commit();
                return runId;
            } catch (Exception ex) {
                connection.rollback();
                throw ex;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    public List<Map<String, Object>> getCandidates(long runId) throws SQLException {
        String sql = """
                SELECT c.candidate_id, c.student_id, s.full_name, s.email, b.batch_name,
                       sr.gpa, c.batch_rank, c.tie_at_cutoff, c.proposed, c.decision
                FROM candidates c
                JOIN students s ON s.student_id = c.student_id
                JOIN batches b ON b.batch_id = c.batch_id
                JOIN selection_runs r ON r.run_id = c.run_id
                JOIN student_results sr ON sr.student_id = c.student_id AND sr.period_code = r.period_code
                WHERE c.run_id = ?
                ORDER BY b.batch_name, c.batch_rank, s.student_id
                """;
        try (Connection connection = Db.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setLong(1, runId);
            try (ResultSet result = statement.executeQuery()) {
                return rows(result);
            }
        }
    }

    public String getRunStatus(long runId) throws SQLException {
        try (Connection connection = Db.getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "SELECT status FROM selection_runs WHERE run_id = ?")) {
            statement.setLong(1, runId);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) {
                    throw new SQLException("Selection run was not found.");
                }
                return result.getString("status");
            }
        }
    }

    public List<Map<String, Object>> getExceptions(long runId) throws SQLException {
        String sql = """
                SELECT e.reason, b.batch_name, e.student_id
                FROM selection_exceptions e
                LEFT JOIN batches b ON b.batch_id = e.batch_id
                WHERE e.run_id = ?
                ORDER BY e.exception_id
                """;
        try (Connection connection = Db.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setLong(1, runId);
            try (ResultSet result = statement.executeQuery()) {
                return rows(result);
            }
        }
    }

    public void confirmAwards(long runId, long staffId, List<Long> selectedIds) throws Exception {
        if (selectedIds.isEmpty() || selectedIds.size() > 500) {
            throw new SQLException("Select at least one candidate and no more than 500 candidates.");
        }
        List<ScholarshipEvent> notifications = new ArrayList<>();
        try (Connection connection = Db.getConnection()) {
            connection.setAutoCommit(false);
            try {
                String period;
                try (PreparedStatement statement = connection.prepareStatement(
                        "SELECT period_code, status FROM selection_runs WHERE run_id=? FOR UPDATE")) {
                    statement.setLong(1, runId);
                    try (ResultSet result = statement.executeQuery()) {
                        if (!result.next()) {
                            throw new SQLException("Selection run was not found.");
                        }
                        period = result.getString("period_code");
                        if (!"REVIEW_PENDING".equals(result.getString("status"))) {
                            throw new SQLException("This selection run has already been confirmed.");
                        }
                    }
                }

                Map<Long, CandidateChoice> choices = loadCandidateChoices(connection, runId);
                Map<Long, Integer> selectedByBatch = new HashMap<>();
                for (Long candidateId : selectedIds) {
                    CandidateChoice candidate = choices.get(candidateId);
                    if (candidate == null || !candidate.proposed()) {
                        throw new SQLException("Only proposed candidates from this selection run can be confirmed.");
                    }
                    selectedByBatch.merge(candidate.batchId(), 1, Integer::sum);
                    if (selectedByBatch.get(candidate.batchId()) > candidate.slots()) {
                        throw new SQLException("The selected count exceeds the configured scholarship slots for a batch.");
                    }
                    notifications.add(new ScholarshipEvent(candidate.id(), candidate.studentId(), candidate.name(),
                            candidate.email(), period, candidate.batchName(), ScholarshipEvent.Type.AWARD));
                }

                try (PreparedStatement select = connection.prepareStatement(
                        "UPDATE candidates SET decision='SELECTED' WHERE candidate_id=? AND run_id=?");
                     PreparedStatement reject = connection.prepareStatement(
                             "UPDATE candidates SET decision='NOT_SELECTED' WHERE run_id=? AND decision='PENDING'");
                     PreparedStatement check = connection.prepareStatement(
                             "INSERT INTO payment_checks (candidate_id) VALUES (?)");
                     PreparedStatement finish = connection.prepareStatement(
                             "UPDATE selection_runs SET status='CONFIRMED', confirmed_by=?, confirmed_at=CURRENT_TIMESTAMP "
                                     + "WHERE run_id=? AND status='REVIEW_PENDING'")) {
                    for (Long candidateId : selectedIds) {
                        select.setLong(1, candidateId);
                        select.setLong(2, runId);
                        if (select.executeUpdate() != 1) {
                            throw new SQLException("A candidate could not be confirmed.");
                        }
                        check.setLong(1, candidateId);
                        check.addBatch();
                    }
                    reject.setLong(1, runId);
                    reject.executeUpdate();
                    check.executeBatch();
                    finish.setLong(1, staffId);
                    finish.setLong(2, runId);
                    if (finish.executeUpdate() != 1) {
                        throw new SQLException("The selection run could not be confirmed.");
                    }
                }
                connection.commit();
            } catch (Exception ex) {
                connection.rollback();
                throw ex;
            } finally {
                connection.setAutoCommit(true);
            }
        }
        publishAll(notifications);
    }

    public void markCheckPrepared(long candidateId, long staffId) throws Exception {
        ScholarshipEvent event;
        try (Connection connection = Db.getConnection()) {
            connection.setAutoCommit(false);
            try (PreparedStatement statement = connection.prepareStatement("""
                    SELECT c.candidate_id, c.student_id, s.full_name, s.email, r.period_code, b.batch_name,
                           p.status AS check_status, r.status AS run_status
                    FROM candidates c
                    JOIN students s ON s.student_id = c.student_id
                    JOIN batches b ON b.batch_id = c.batch_id
                    JOIN selection_runs r ON r.run_id = c.run_id
                    JOIN payment_checks p ON p.candidate_id = c.candidate_id
                    WHERE c.candidate_id = ? FOR UPDATE
                    """)) {
                statement.setLong(1, candidateId);
                try (ResultSet result = statement.executeQuery()) {
                    if (!result.next() || !"CONFIRMED".equals(result.getString("run_status"))) {
                        throw new SQLException("Only a confirmed scholarship candidate can have a prepared check.");
                    }
                    if ("PREPARED".equals(result.getString("check_status"))) {
                        throw new SQLException("This check has already been marked prepared.");
                    }
                    event = new ScholarshipEvent(result.getLong("candidate_id"), result.getString("student_id"),
                            result.getString("full_name"), result.getString("email"), result.getString("period_code"),
                            result.getString("batch_name"), ScholarshipEvent.Type.CHECK_COLLECTION);
                }
                try (PreparedStatement update = connection.prepareStatement("""
                        UPDATE payment_checks SET status='PREPARED', prepared_at=CURRENT_TIMESTAMP, prepared_by=?
                        WHERE candidate_id=? AND status='PENDING'
                        """)) {
                    update.setLong(1, staffId);
                    update.setLong(2, candidateId);
                    if (update.executeUpdate() != 1) {
                        throw new SQLException("The check status changed. Refresh and try again.");
                    }
                }
                connection.commit();
            } catch (Exception ex) {
                connection.rollback();
                throw ex;
            } finally {
                connection.setAutoCommit(true);
            }
        }
        events.publish(event);
    }

    private List<BatchResults> loadBatchResults(Connection connection, String period) throws SQLException {
        String sql = """
                SELECT b.batch_id, b.batch_name, sr.student_id, s.full_name, s.email, sr.gpa,
                       rule.slots_per_batch, rule.minimum_gpa
                FROM student_results sr
                JOIN students s ON s.student_id = sr.student_id AND s.active = TRUE
                JOIN batches b ON b.batch_id = s.batch_id
                LEFT JOIN scholarship_rules rule
                  ON rule.batch_id = b.batch_id AND rule.period_code = sr.period_code
                WHERE sr.period_code = ?
                ORDER BY b.batch_id, sr.gpa DESC, sr.student_id
                """;
        Map<Long, BatchResultsBuilder> grouped = new HashMap<>();
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, period);
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    long batchId = result.getLong("batch_id");
                    BatchResultsBuilder builder = grouped.computeIfAbsent(batchId, ignored ->
                            new BatchResultsBuilder(batchId, readString(result, "batch_name"),
                                    readInteger(result, "slots_per_batch"), readDecimal(result, "minimum_gpa")));
                    if (builder.slots() != null) {
                        builder.students().add(new RankedStudent(result.getString("student_id"), batchId,
                                result.getString("batch_name"), result.getString("full_name"),
                                result.getString("email"), result.getBigDecimal("gpa"), 0, false, false));
                    }
                }
            }
        }
        return grouped.values().stream().map(BatchResultsBuilder::build).toList();
    }

    private long insertRun(Connection connection, String period, long staffId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO selection_runs (period_code, created_by) VALUES (?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, period);
            statement.setLong(2, staffId);
            statement.executeUpdate();
            try (ResultSet keys = statement.getGeneratedKeys()) {
                if (!keys.next()) {
                    throw new SQLException("The selection run could not be saved.");
                }
                return keys.getLong(1);
            }
        }
    }

    private void saveCandidates(Connection connection, long runId, List<RankedStudent> ranked) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                INSERT INTO candidates (run_id, student_id, batch_id, batch_rank, tie_at_cutoff, proposed)
                VALUES (?, ?, ?, ?, ?, ?)
                """)) {
            for (RankedStudent student : ranked) {
                statement.setLong(1, runId);
                statement.setString(2, student.studentId());
                statement.setLong(3, student.batchId());
                statement.setInt(4, student.rank());
                statement.setBoolean(5, student.tieAtCutoff());
                statement.setBoolean(6, student.proposed());
                statement.addBatch();
            }
            statement.executeBatch();
        }
    }

    private void insertException(Connection connection, long runId, long batchId, String studentId, String reason)
            throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO selection_exceptions (run_id, batch_id, student_id, reason) VALUES (?, ?, ?, ?)")) {
            statement.setLong(1, runId);
            statement.setLong(2, batchId);
            statement.setString(3, studentId);
            statement.setString(4, reason);
            statement.executeUpdate();
        }
    }

    private Map<Long, CandidateChoice> loadCandidateChoices(Connection connection, long runId) throws SQLException {
        Map<Long, CandidateChoice> choices = new HashMap<>();
        String sql = """
                SELECT c.candidate_id, c.student_id, c.proposed, b.batch_id, b.batch_name,
                       s.full_name, s.email, rule.slots_per_batch
                FROM candidates c
                JOIN students s ON s.student_id = c.student_id
                JOIN batches b ON b.batch_id = c.batch_id
                JOIN selection_runs run ON run.run_id = c.run_id
                JOIN scholarship_rules rule
                  ON rule.batch_id = b.batch_id AND rule.period_code = run.period_code
                WHERE c.run_id = ?
                """;
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setLong(1, runId);
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    CandidateChoice choice = new CandidateChoice(result.getLong("candidate_id"),
                            result.getString("student_id"), result.getBoolean("proposed"),
                            result.getLong("batch_id"), result.getInt("slots_per_batch"),
                            result.getString("batch_name"), result.getString("full_name"),
                            result.getString("email"));
                    choices.put(choice.id(), choice);
                }
            }
        }
        return choices;
    }

    private List<Map<String, Object>> rows(ResultSet result) throws SQLException {
        List<Map<String, Object>> rows = new ArrayList<>();
        int count = result.getMetaData().getColumnCount();
        while (result.next()) {
            Map<String, Object> row = new HashMap<>();
            for (int i = 1; i <= count; i++) {
                row.put(result.getMetaData().getColumnLabel(i), result.getObject(i));
            }
            rows.add(row);
        }
        return rows;
    }

    private void publishAll(List<ScholarshipEvent> notifications) throws Exception {
        Exception failure = null;
        for (ScholarshipEvent notification : notifications) {
            try {
                events.publish(notification);
            } catch (Exception ex) {
                if (failure == null) {
                    failure = new Exception("Awards were confirmed, but one or more emails failed. Check the email log.");
                }
                failure.addSuppressed(ex);
            }
        }
        if (failure != null) {
            throw failure;
        }
    }

    private String readString(ResultSet result, String column) {
        try {
            return result.getString(column);
        } catch (SQLException ex) {
            throw new IllegalStateException(ex);
        }
    }

    private Integer readInteger(ResultSet result, String column) {
        try {
            int value = result.getInt(column);
            return result.wasNull() ? null : value;
        } catch (SQLException ex) {
            throw new IllegalStateException(ex);
        }
    }

    private BigDecimal readDecimal(ResultSet result, String column) {
        try {
            return result.getBigDecimal(column);
        } catch (SQLException ex) {
            throw new IllegalStateException(ex);
        }
    }

    private record BatchResults(long batchId, String batchName, Integer slots, BigDecimal minimumGpa,
                                List<RankedStudent> students) {
    }

    private static final class BatchResultsBuilder {
        private final long batchId;
        private final String batchName;
        private final Integer slots;
        private final BigDecimal minimumGpa;
        private final List<RankedStudent> students = new ArrayList<>();

        private BatchResultsBuilder(long batchId, String batchName, Integer slots, BigDecimal minimumGpa) {
            this.batchId = batchId;
            this.batchName = batchName;
            this.slots = slots;
            this.minimumGpa = minimumGpa;
        }

        private List<RankedStudent> students() {
            return students;
        }

        private Integer slots() {
            return slots;
        }

        private BatchResults build() {
            return new BatchResults(batchId, batchName, slots, minimumGpa, students);
        }
    }

    private record CandidateChoice(long id, String studentId, boolean proposed, long batchId, int slots,
                                   String batchName, String name, String email) {
    }
}
