package edu.university.scholarship.web;

import edu.university.scholarship.workflow.ScholarshipWorkflowFacade;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ReleaseResultsServlet extends HttpServlet {
    private final ScholarshipWorkflowFacade workflow = new ScholarshipWorkflowFacade();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (!Web.validCsrf(request)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Your form expired. Please try again.");
            return;
        }
        String period = Web.parameter(request, "period");
        if (!period.matches("[A-Za-z0-9_-]{2,32}")) {
            Web.flash(request, "error", "Choose a valid result period.");
            response.sendRedirect(request.getContextPath() + "/staff/dashboard");
            return;
        }
        try {
            long runId = workflow.releaseResultsAndPrepareCandidates(period, Web.staffId(request));
            Web.flash(request, "success", "Results released. Review the generated candidate list before confirming awards.");
            response.sendRedirect(request.getContextPath() + "/staff/candidates?runId=" + runId);
        } catch (Exception ex) {
            Web.flash(request, "error", ex.getMessage());
            response.sendRedirect(request.getContextPath() + "/staff/dashboard");
        }
    }
}
