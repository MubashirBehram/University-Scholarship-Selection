package edu.university.scholarship.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class Db {
    private Db() {
    }

    public static Connection getConnection() throws SQLException {
        String url = System.getenv("DB_URL");
        String user = System.getenv("DB_USER");
        String password = System.getenv("DB_PASSWORD");
        if (url == null || url.isBlank()) {
            url = "jdbc:mariadb://127.0.0.1:3307/university_scholarship";
        }
        if (user == null || user.isBlank()) {
            user = "root";
        }
        if (password == null) {
            password = "";
        }
        try {
            Class.forName("org.mariadb.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            throw new SQLException("MariaDB JDBC driver is missing from the deployed application.", ex);
        }
        return DriverManager.getConnection(url, user, password);
    }
}
