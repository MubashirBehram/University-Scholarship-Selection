package edu.university.scholarship.workflow;

public interface ScholarshipEventListener {
    void onEvent(ScholarshipEvent event) throws Exception;
}
