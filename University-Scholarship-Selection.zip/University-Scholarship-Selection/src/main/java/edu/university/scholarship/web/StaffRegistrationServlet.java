package edu.university.scholarship.web;

import edu.university.scholarship.config.Db;
import edu.university.scholarship.security.PasswordUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/register")
public class StaffRegistrationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("csrfToken", Web.csrfToken(request.getSession()));
        Web.consumeFlash(request);
        request.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (!Web.validCsrf(request)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Your form expired. Please try again.");
            return;
        }
        String name = Web.parameter(request, "fullName");
        String email = Web.parameter(request, "email").toLowerCase();
        String password = request.getParameter("password");
        String confirmation = request.getParameter("confirmPassword");
        String invite = request.getParameter("inviteCode");
        String configuredInvite = System.getenv("STAFF_INVITE_CODE");
        if (configuredInvite == null || configuredInvite.isBlank()) {
            configuredInvite = System.getProperty("STAFF_INVITE_CODE");
        }
        if (configuredInvite == null || invite == null || !MessageDigest.isEqual(
                configuredInvite.getBytes(StandardCharsets.UTF_8), invite.getBytes(StandardCharsets.UTF_8))) {
            Web.flash(request, "error", "The staff invitation code is invalid.");
            response.sendRedirect(request.getContextPath() + "/register");
            return;
        }
        if (name.length() < 2 || name.length() > 120 || !name.matches("[\\p{L}][\\p{L} .'-]{1,119}")
                || !Web.validEmail(email) || password == null || !Web.validPassword(password)
                || !password.equals(confirmation)) {
            Web.flash(request, "error",
                    "Check your name and email. Passwords must be 12-128 characters with uppercase and lowercase letters, a number, a symbol, and a matching confirmation.");
            response.sendRedirect(request.getContextPath() + "/register");
            return;
        }
        String sql = "INSERT INTO staff_users (full_name, email, password_hash) VALUES (?, ?, ?)";
        try (Connection connection = Db.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, PasswordUtil.hash(password.toCharArray()));
            statement.executeUpdate();
            Web.flash(request, "success", "Staff account created. You can now sign in.");
            response.sendRedirect(request.getContextPath() + "/login");
        } catch (SQLException ex) {
            if ("23000".equals(ex.getSQLState())) {
                Web.flash(request, "error", "An account already exists for that email address.");
                response.sendRedirect(request.getContextPath() + "/register");
                return;
            }
            throw new ServletException("Unable to create the staff account. Check the database configuration.", ex);
        } finally {
            if (password != null) {
                java.util.Arrays.fill(password.toCharArray(), '\0');
            }
            if (confirmation != null) {
                java.util.Arrays.fill(confirmation.toCharArray(), '\0');
            }
        }
    }
}
