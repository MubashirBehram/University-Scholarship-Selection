package edu.university.scholarship.workflow;

import java.math.BigDecimal;
import java.util.List;

public interface ScholarshipSelectionStrategy {
    List<RankedStudent> rank(List<RankedStudent> students, int slots, BigDecimal minimumGpa);
}
