package edu.university.scholarship.web;

import edu.university.scholarship.config.Db;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/contact")
public class ContactServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("csrfToken", Web.csrfToken(request.getSession()));
        Web.consumeFlash(request);
        request.getRequestDispatcher("/WEB-INF/views/contact.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (!Web.validCsrf(request)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Your form expired. Please try again.");
            return;
        }
        String name = Web.parameter(request, "name");
        String email = Web.parameter(request, "email").toLowerCase();
        String subject = Web.parameter(request, "subject");
        String message = Web.parameter(request, "message");
        if (name.length() < 2 || name.length() > 120 || !name.matches("[\\p{L}][\\p{L} .'-]{1,119}")
                || !Web.validEmail(email) || subject.length() < 3 || subject.length() > 160
                || message.length() < 10 || message.length() > 3000) {
            Web.flash(request, "error", "Please check each field and meet the length requirements.");
            response.sendRedirect(request.getContextPath() + "/contact");
            return;
        }
        String sql = "INSERT INTO contact_messages (sender_name, sender_email, subject, message_body) VALUES (?, ?, ?, ?)";
        try (Connection connection = Db.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, subject);
            statement.setString(4, message);
            statement.executeUpdate();
            Web.flash(request, "success", "Your message was sent to the scholarship office.");
            response.sendRedirect(request.getContextPath() + "/contact");
        } catch (Exception ex) {
            throw new ServletException("Unable to save your message. Check the database configuration and try again.", ex);
        }
    }
}
