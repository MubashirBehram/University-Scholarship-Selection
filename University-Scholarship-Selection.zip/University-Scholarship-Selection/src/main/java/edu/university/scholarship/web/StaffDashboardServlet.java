package edu.university.scholarship.web;

import edu.university.scholarship.config.Db;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/staff/dashboard")
public class StaffDashboardServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (Connection connection = Db.getConnection()) {
            request.setAttribute("batchCount", count(connection, "SELECT COUNT(*) FROM batches"));
            request.setAttribute("studentCount", count(connection, "SELECT COUNT(*) FROM students"));
            request.setAttribute("resultCount", count(connection, "SELECT COUNT(*) FROM student_results"));
            request.setAttribute("ruleCount", count(connection, "SELECT COUNT(*) FROM scholarship_rules"));
        } catch (Exception ex) {
            throw new ServletException("Unable to load the staff dashboard. Check the database and schema.", ex);
        }
        request.setAttribute("csrfToken", Web.csrfToken(request.getSession()));
        Web.consumeFlash(request);
        request.getRequestDispatcher("/WEB-INF/views/staff/dashboard.jsp").forward(request, response);
    }

    private long count(Connection connection, String sql) throws Exception {
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet result = statement.executeQuery()) {
            result.next();
            return result.getLong(1);
        }
    }
}
