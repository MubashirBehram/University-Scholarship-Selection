package edu.university.scholarship.web;

import edu.university.scholarship.workflow.ScholarshipWorkflowFacade;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class PrepareCheckServlet extends HttpServlet {
    private final ScholarshipWorkflowFacade workflow = new ScholarshipWorkflowFacade();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (!Web.validCsrf(request)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Your form expired. Please try again.");
            return;
        }
        try {
            long candidateId = Long.parseLong(Web.parameter(request, "candidateId"));
            workflow.markCheckPrepared(candidateId, Web.staffId(request));
            Web.flash(request, "success", "Check marked prepared. Collection email delivery was logged.");
        } catch (NumberFormatException ex) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "A valid candidate is required.");
            return;
        } catch (Exception ex) {
            Web.flash(request, "error", ex.getMessage());
        }
        response.sendRedirect(request.getContextPath() + "/staff/dashboard");
    }
}
