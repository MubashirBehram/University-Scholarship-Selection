package edu.university.scholarship.workflow;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class TopNPerBatchStrategy implements ScholarshipSelectionStrategy {
    @Override
    public List<RankedStudent> rank(List<RankedStudent> students, int slots, BigDecimal minimumGpa) {
        List<RankedStudent> eligible = students.stream()
                .filter(student -> student.gpa().compareTo(minimumGpa) >= 0)
                .sorted(Comparator.comparing(RankedStudent::gpa).reversed()
                        .thenComparing(RankedStudent::studentId))
                .toList();

        List<RankedStudent> ranked = new ArrayList<>(eligible.size());
        BigDecimal cutoff = eligible.size() >= slots ? eligible.get(slots - 1).gpa() : null;
        for (int index = 0; index < eligible.size(); index++) {
            RankedStudent student = eligible.get(index);
            boolean tieAtCutoff = cutoff != null && student.gpa().compareTo(cutoff) == 0;
            boolean proposed = index < slots || tieAtCutoff;
            ranked.add(new RankedStudent(student.studentId(), student.batchId(), student.batchName(),
                    student.fullName(), student.email(), student.gpa(), index + 1, tieAtCutoff, proposed));
        }
        return ranked;
    }
}
