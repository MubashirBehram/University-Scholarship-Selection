package edu.university.scholarship.web;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/staff/*")
public class StaffAuthFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(false);
        if (session == null || !(session.getAttribute("staffId") instanceof Long)) {
            Web.flash(httpRequest, "info", "Sign in with your staff account to continue.");
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login");
            return;
        }
        httpResponse.setHeader("Cache-Control", "no-store");
        chain.doFilter(request, response);
    }
}
