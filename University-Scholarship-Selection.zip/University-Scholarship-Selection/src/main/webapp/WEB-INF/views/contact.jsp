<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Contact | University Scholarship Office"/>
<%@ include file="fragments/head.jspf" %>
<section class="page-heading">
  <span class="eyebrow">Contact</span>
  <h1>Get in touch with the scholarship office.</h1>
  <p>Use this form for questions about scholarship selection or recipient notifications. Students do not apply through this website.</p>
</section>
<section class="contact-layout">
  <div class="contact-info">
    <h2>How this system works</h2>
    <p>Scholarship staff use existing university result and student records to identify candidates. Staff confirm awards before award emails are sent.</p>
    <p>A separate collection message is sent only after staff mark a scholarship check as prepared.</p>
    <div class="notice info">Please do not include passwords, student grades, or other sensitive personal information in your message.</div>
  </div>
  <div class="form-card">
    <h2>Send a message</h2>
    <c:if test="${not empty flashMessage}">
      <div class="notice ${flashType}" role="status"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="post" action="${pageContext.request.contextPath}/contact">
      <input type="hidden" name="_csrf" value="<c:out value='${csrfToken}'/>">
      <label for="name">Name</label>
      <input id="name" name="name" type="text" autocomplete="name" minlength="2" maxlength="120" required>
      <label for="email">Email</label>
      <input id="email" name="email" type="email" autocomplete="email" maxlength="254" required>
      <label for="subject">Subject</label>
      <input id="subject" name="subject" type="text" minlength="3" maxlength="160" required>
      <label for="message">Message</label>
      <textarea id="message" name="message" rows="6" minlength="10" maxlength="3000" required></textarea>
      <button class="button primary" type="submit">Send message</button>
    </form>
  </div>
</section>
<%@ include file="fragments/foot.jspf" %>
