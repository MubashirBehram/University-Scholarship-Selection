<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Staff dashboard | University Scholarship Office"/>
<%@ include file="../fragments/head.jspf" %>
<section class="dashboard-heading">
  <div>
    <span class="eyebrow">40% evaluation milestone</span>
    <h1>Staff dashboard</h1>
    <p>Welcome, <strong><c:out value="${sessionScope.staffName}"/></strong>. Database connectivity is working.</p>
  </div>
  <a class="button secondary" href="${pageContext.request.contextPath}/contact">Contact support</a>
</section>

<c:if test="${not empty flashMessage}">
  <div class="notice ${flashType}" role="status"><c:out value="${flashMessage}"/></div>
</c:if>

<section class="section-block">
  <div class="section-heading compact">
    <span class="eyebrow">Connected database records</span>
    <h2>Scholarship data foundation</h2>
    <p>These counts are read from MariaDB through the Java application.</p>
  </div>
  <div class="feature-grid">
    <article class="feature-card"><span class="feature-number">01</span><h3>Batches</h3><p><strong><c:out value="${batchCount}"/></strong> batch records</p></article>
    <article class="feature-card"><span class="feature-number">02</span><h3>Students</h3><p><strong><c:out value="${studentCount}"/></strong> student records</p></article>
    <article class="feature-card"><span class="feature-number">03</span><h3>Results</h3><p><strong><c:out value="${resultCount}"/></strong> result records</p></article>
    <article class="feature-card"><span class="feature-number">04</span><h3>Scholarship rules</h3><p><strong><c:out value="${ruleCount}"/></strong> configured rules</p></article>
  </div>
</section>

<section class="callout">
  <div>
    <span class="eyebrow">Next development phase</span>
    <h2>Selection and notification workflow</h2>
    <p>Result release, batch ranking, staff confirmation, payment checks, and email notifications are planned according to the proposal for the next evaluation.</p>
  </div>
</section>
<%@ include file="../fragments/foot.jspf" %>
