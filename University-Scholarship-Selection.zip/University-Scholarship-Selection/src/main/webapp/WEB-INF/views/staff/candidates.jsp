<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Candidate review | University Scholarship Office"/>
<%@ include file="../fragments/head.jspf" %>
<section class="dashboard-heading">
  <div>
    <span class="eyebrow">Staff review</span>
    <h1>Candidate list <span class="heading-sub">Run #<c:out value="${runId}"/></span></h1>
    <p>Proposed candidates are ranked within their batch. Cutoff ties are flagged; select no more than the configured slots for each batch.</p>
  </div>
  <a class="button secondary" href="${pageContext.request.contextPath}/staff/dashboard">Back to dashboard</a>
</section>
<c:if test="${not empty flashMessage}">
  <div class="notice ${flashType}" role="status"><c:out value="${flashMessage}"/></div>
</c:if>
<c:if test="${not empty exceptions}">
  <section class="dashboard-section">
    <div class="notice warning">
      <strong>Review data exceptions</strong>
      <ul>
        <c:forEach var="exception" items="${exceptions}">
          <li><c:out value="${exception.batch_name}"/>: <c:out value="${exception.reason}"/></li>
        </c:forEach>
      </ul>
    </div>
  </section>
</c:if>
<section class="dashboard-section">
  <c:choose>
    <c:when test="${runStatus == 'REVIEW_PENDING'}">
      <form method="post" action="${pageContext.request.contextPath}/staff/awards/confirm">
        <input type="hidden" name="_csrf" value="<c:out value='${csrfToken}'/>">
        <input type="hidden" name="runId" value="<c:out value='${runId}'/>">
        <div class="table-wrap">
          <table>
            <thead><tr><th>Select</th><th>Batch</th><th>Rank</th><th>Student</th><th>Student ID</th><th>GPA</th><th>Recommendation</th><th>Cutoff tie</th></tr></thead>
            <tbody>
            <c:forEach var="candidate" items="${candidates}">
              <tr class="${candidate.proposed ? 'candidate-row' : ''}">
                <td>
                  <c:if test="${candidate.proposed}">
                    <input class="candidate-check" type="checkbox" name="candidateIds" value="<c:out value='${candidate.candidate_id}'/>" aria-label="Select <c:out value='${candidate.full_name}'/>">
                  </c:if>
                </td>
                <td><c:out value="${candidate.batch_name}"/></td>
                <td><c:out value="${candidate.batch_rank}"/></td>
                <td><c:out value="${candidate.full_name}"/><small class="table-sub"><c:out value="${candidate.email}"/></small></td>
                <td><c:out value="${candidate.student_id}"/></td>
                <td><c:out value="${candidate.gpa}"/></td>
                <td><c:choose><c:when test="${candidate.proposed}"><span class="status-pill success">Review candidate</span></c:when><c:otherwise><span class="status-pill">Not in top slots</span></c:otherwise></c:choose></td>
                <td><c:if test="${candidate.tie_at_cutoff}"><span class="status-pill warning-pill">Tie at cutoff</span></c:if></td>
              </tr>
            </c:forEach>
            <c:if test="${empty candidates}"><tr><td colspan="8" class="empty-cell">No candidate records were generated.</td></tr></c:if>
            </tbody>
          </table>
        </div>
        <div class="review-actions">
          <p class="muted">Confirming sends award emails to the selected recipients. This cannot be undone.</p>
          <button class="button primary" type="submit" <c:if test="${empty candidates}">disabled</c:if>>Confirm selected awards</button>
        </div>
      </form>
    </c:when>
    <c:otherwise>
      <div class="notice success">This run is confirmed. Award email delivery results are available on the staff dashboard.</div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Batch</th><th>Rank</th><th>Student</th><th>Student ID</th><th>GPA</th><th>Decision</th><th>Cutoff tie</th></tr></thead>
          <tbody>
          <c:forEach var="candidate" items="${candidates}">
            <tr>
              <td><c:out value="${candidate.batch_name}"/></td><td><c:out value="${candidate.batch_rank}"/></td>
              <td><c:out value="${candidate.full_name}"/></td><td><c:out value="${candidate.student_id}"/></td>
              <td><c:out value="${candidate.gpa}"/></td><td><c:out value="${candidate.decision}"/></td>
              <td><c:if test="${candidate.tie_at_cutoff}">Tie at cutoff</c:if></td>
            </tr>
          </c:forEach>
          </tbody>
        </table>
      </div>
    </c:otherwise>
  </c:choose>
</section>
<%@ include file="../fragments/foot.jspf" %>
