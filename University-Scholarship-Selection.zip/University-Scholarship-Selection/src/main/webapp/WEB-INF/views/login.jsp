<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Staff sign in | University Scholarship Office"/>
<%@ include file="fragments/head.jspf" %>
<section class="auth-layout">
  <div class="auth-aside">
    <span class="eyebrow">Staff access</span>
    <h1>Welcome back.</h1>
    <p>Sign in to review scholarship selections, confirm awards, and update payment-check status.</p>
    <ul class="check-list">
      <li>University staff accounts only</li>
      <li>Candidate lists require staff confirmation</li>
      <li>Recipient email history stays auditable</li>
    </ul>
  </div>
  <div class="form-card">
    <h2>Staff sign in</h2>
    <p class="muted">Use your authorized scholarship-office account.</p>
    <c:if test="${not empty flashMessage}">
      <div class="notice ${flashType}" role="alert"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="post" action="${pageContext.request.contextPath}/login">
      <input type="hidden" name="_csrf" value="<c:out value='${csrfToken}'/>">
      <label for="email">Work email</label>
      <input id="email" name="email" type="email" autocomplete="username" maxlength="254" required>
      <label for="password">Password</label>
      <input id="password" name="password" type="password" autocomplete="current-password" maxlength="128" required>
      <button class="button primary full-width" type="submit">Sign in</button>
    </form>
    <p class="form-footnote">Need staff access? <a href="${pageContext.request.contextPath}/register">Register with an invitation code</a>.</p>
  </div>
</section>
<%@ include file="fragments/foot.jspf" %>
