<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Home | University Scholarship Office"/>
<%@ include file="fragments/head.jspf" %>
<c:if test="${not empty flashMessage}">
  <div class="notice ${flashType}" role="status"><c:out value="${flashMessage}"/></div>
</c:if>
<section class="hero">
  <div class="hero-copy">
    <span class="eyebrow">A clearer scholarship process</span>
    <h1>Recognize achievement.<br><span>Reach students on time.</span></h1>
    <p>Use released university results to prepare scholarship candidates for each batch. Staff review and confirm awards; students receive clear email updates when awards are confirmed and checks are ready.</p>
    <div class="hero-actions">
      <c:choose>
        <c:when test="${not empty sessionScope.staffId}">
          <a class="button primary" href="${pageContext.request.contextPath}/staff/dashboard">Open staff dashboard</a>
        </c:when>
        <c:otherwise>
          <a class="button primary" href="${pageContext.request.contextPath}/login">Staff sign in</a>
          <a class="button secondary" href="${pageContext.request.contextPath}/contact">Contact the office</a>
        </c:otherwise>
      </c:choose>
    </div>
    <p class="small-note">Students do not apply through this system. Selection uses existing university records.</p>
  </div>
  <aside class="hero-card">
    <div class="card-icon" aria-hidden="true">✦</div>
    <p class="card-label">The workflow</p>
    <ol class="mini-steps">
      <li><span>01</span> Results are released</li>
      <li><span>02</span> Candidates are ranked by batch</li>
      <li><span>03</span> Staff confirm scholarship awards</li>
      <li><span>04</span> Award and check emails are sent</li>
    </ol>
  </aside>
</section>

<section class="section-block">
  <div class="section-heading">
    <span class="eyebrow">Built around the real process</span>
    <h2>Less list handling. Clearer communication.</h2>
    <p>A staff-focused workflow that keeps the selection decision in human hands.</p>
  </div>
  <div class="feature-grid">
    <article class="feature-card">
      <span class="feature-number">01</span>
      <h3>Batch-based selection</h3>
      <p>Apply each batch's scholarship slots and eligibility rule to released result records.</p>
    </article>
    <article class="feature-card">
      <span class="feature-number">02</span>
      <h3>Staff review first</h3>
      <p>Review rankings, cutoff ties, and record exceptions before confirming recipients.</p>
    </article>
    <article class="feature-card">
      <span class="feature-number">03</span>
      <h3>Timely email notices</h3>
      <p>Notify recipients after award confirmation and again when staff prepare checks.</p>
    </article>
  </div>
</section>

<section class="callout">
  <div>
    <span class="eyebrow">For university scholarship staff</span>
    <h2>Keep each decision traceable.</h2>
    <p>Selection runs, staff confirmations, check status, and email delivery outcomes are recorded for review.</p>
  </div>
  <a class="button light" href="${pageContext.request.contextPath}/contact">Contact the scholarship office</a>
</section>
<%@ include file="fragments/foot.jspf" %>
