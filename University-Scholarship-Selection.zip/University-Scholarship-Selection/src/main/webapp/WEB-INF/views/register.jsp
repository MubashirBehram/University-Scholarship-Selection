<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Staff registration | University Scholarship Office"/>
<%@ include file="fragments/head.jspf" %>
<section class="auth-layout">
  <div class="auth-aside">
    <span class="eyebrow">Restricted registration</span>
    <h1>Create a staff account.</h1>
    <p>Only authorized scholarship-office staff can access student result records and selection tools.</p>
    <ul class="check-list">
      <li>A private invitation code is required</li>
      <li>Use a university work email</li>
      <li>Choose a unique password with upper/lowercase letters, a number, and a symbol</li>
    </ul>
  </div>
  <div class="form-card">
    <h2>Staff registration</h2>
    <p class="muted">Invitation-only. Do not share the invitation code.</p>
    <c:if test="${not empty flashMessage}">
      <div class="notice ${flashType}" role="alert"><c:out value="${flashMessage}"/></div>
    </c:if>
    <form method="post" action="${pageContext.request.contextPath}/register">
      <input type="hidden" name="_csrf" value="<c:out value='${csrfToken}'/>">
      <label for="fullName">Full name</label>
      <input id="fullName" name="fullName" type="text" autocomplete="name" minlength="2" maxlength="120" required>
      <label for="email">Work email</label>
      <input id="email" name="email" type="email" autocomplete="email" maxlength="254" required>
      <div class="form-row">
        <div>
          <label for="password">Password</label>
          <input id="password" name="password" type="password" autocomplete="new-password" minlength="12" maxlength="128" pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{12,128}" title="Use 12-128 characters with uppercase and lowercase letters, a number, and a symbol." required>
        </div>
        <div>
          <label for="confirmPassword">Confirm password</label>
          <input id="confirmPassword" name="confirmPassword" type="password" autocomplete="new-password" minlength="12" maxlength="128" required>
        </div>
      </div>
      <label for="inviteCode">Staff invitation code</label>
      <input id="inviteCode" name="inviteCode" type="password" autocomplete="off" maxlength="128" required>
      <button class="button primary full-width" type="submit">Create staff account</button>
    </form>
    <p class="form-footnote">Already registered? <a href="${pageContext.request.contextPath}/login">Sign in</a>.</p>
  </div>
</section>
<%@ include file="fragments/foot.jspf" %>
