# University Scholarship Selection and Notification

A Java Servlet/JSP and MariaDB application for the first 40% milestone of a university scholarship selection and notification system. The milestone implements the required pages, validation, staff access foundation, and database connectivity. The later selection-confirmation and notification workflow remains staged for the next evaluation.

## Stack

- Java 17+, Jakarta Servlet 6, JSP/JSTL
- MySQL/MariaDB with XAMPP and MariaDB Connector/J
- Apache Tomcat 10.1
- Apache Ant

## Database setup

1. Start MySQL from XAMPP.
2. In phpMyAdmin, import `src/main/resources/schema.sql`.
3. Optionally import `src/main/resources/demo-data.sql` to create synthetic batches, results, and rules. Replace the `example.edu` addresses before enabling mail.
4. Configure these environment variables before starting Tomcat:

   - `DB_URL`: e.g. `jdbc:mariadb://localhost:3307/university_scholarship`
   - `DB_USER`
   - `DB_PASSWORD`
   - `STAFF_INVITE_CODE`: a private code required to create staff accounts

Example PowerShell setup for a local XAMPP MariaDB server (adjust the username/password to match your MySQL settings):

```powershell
$env:DB_URL = "jdbc:mariadb://localhost:3307/university_scholarship"
$env:DB_USER = "root"
$env:DB_PASSWORD = "<your local database password>"
$env:STAFF_INVITE_CODE = "<choose a private invitation code>"
```

For the included XAMPP setup, the application defaults to MariaDB on port `3307` with the `root` user and an empty local password when these database variables are not supplied. Set the variables explicitly for any non-default or shared database.

Do not commit real passwords, SMTP credentials, invite codes, or student data. The included SQL demo records are synthetic.

## Ant build and deploy

Install Apache Ant and Tomcat 10.1, then run from this directory:

```text
ant clean war
```

The generated file is `dist\scholarship-selection.war`. Copy it into Tomcat's `webapps` directory and start Tomcat. The required dependency JARs are stored in `lib`, as expected for an Ant/NetBeans-style Java web project.

### Open in Apache NetBeans

Open the project folder in NetBeans using **File > Open Project**. NetBeans uses the included `nbproject\project.xml` and `build.xml` files to load it as an Ant freeform project. If the folder was already shown as `[unloadable]`, close the Open Project dialog, reopen it, and select the same project folder again.

## Initial staff account

Use the staff registration page and the private `STAFF_INVITE_CODE` to create the first staff account. Registration is not public without that code. Passwords are stored using PBKDF2; login sessions are staff-only.

## Current 40% milestone

The current evaluation scope includes:

1. Home page, staff registration, staff sign-in, and Contact Us page.
2. Client-side and server-side validation for required fields, email, and strong passwords.
3. Staff authentication foundation and protected staff area.
4. MariaDB schema and sample data connected to the Java application.
5. Proposal-aligned database foundation for students, batches, result periods, and scholarship rules.

The following proposal features are intentionally staged for later work: result release processing, candidate ranking review, award confirmation, payment-check preparation, and real SMTP notifications. They are not required for the first 40% evaluation.

The staff registration page, sign-in page, home page, contact page, review screen, and check-status screen are intentionally staff-facing; there is no student scholarship application CMS.

## Prototype boundaries

- This prototype does not connect to an existing university student-information/results system. Student and result records must be loaded into the database before a staff member releases a result period.
- Scholarship rules are currently configured directly in the database; there is no rules-editing screen.
- The included demo records are synthetic. Replace them with authorized test data before demonstrating the workflow.
